package snippet;

public class Snippet {
	public static void main(String[] args) {
		.\bin\windows\kafka-server-start.bat .\config\server.properties
	}
}

